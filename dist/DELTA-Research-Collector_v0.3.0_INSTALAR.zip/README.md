# DELTA Research Collector v0.3.0

Extensão experimental para **Opera GX / Chrome / Edge (Manifest V3)**. Um botão sobre páginas científicas exporta resultados de busca em **CSV, BibTeX, RIS (Zotero) ou JSON**. Esta versão também salva, quando autorizado pelo controle marcado, os resultados em uma **biblioteca unificada local** e deduplica por DOI normalizado entre fontes. Nenhuma conta, token ou servidor da DELTA IA é utilizado.

## Instalação no Opera GX

1. **Extraia** o ZIP por completo numa pasta que não será apagada.
2. Abra `opera://extensions`, habilite o **Modo do desenvolvedor**.
3. **Remova ou desative a versão 0.2.0** para não exibir dois botões. Essa versão não guardava biblioteca local, então não há dados históricos a migrar.
4. Clique em **Carregar sem compactação** e selecione a pasta extraída com **`manifest.json` na raiz** (junto com `content.js`, `background.js`, `collector-core.js` e `icons/`).
5. Recarregue uma página de busca compatível. Clique em **BAIXAR BUSCA** para exportar até 200 registros em CSV, ou na **engrenagem** para selecionar formato, limite, biblioteca, histórico e opções da base.
6. No final, procure os arquivos em Downloads (`Ctrl + J`). A extensão solicita o download; a conclusão efetiva depende do navegador.

## Dez bases e URLs de teste

| Base | URL de teste | Método e limites |
|---|---|---|
| **arXiv** | `https://arxiv.org/search/?query=bioinformatics&searchtype=all&size=50` | Extrai HTML das páginas; até 20 PDFs do arXiv opcionais. |
| **Europe PMC** | `https://europepmc.org/search?query=dengue` | API Europe PMC paginada. |
| **PubMed** | `https://pubmed.ncbi.nlm.nih.gov/?term=dengue` | ESearch + EFetch; bloqueia filtros laterais que não consiga converter fielmente. |
| **OpenAlex** | `https://openalex.org/works?search=genomics` | API OpenAlex; limites da API aplicáveis. |
| **Crossref** | `https://search.crossref.org/?q=biomarkers` | API Crossref; ranking e cobertura podem divergir da interface. |
| **Semantic Scholar** | `https://www.semanticscholar.org/search?q=transcriptomics` | API Academic Graph; até 1.000 em relevância; pode retornar 429. |
| **DOAJ** | `https://doaj.org/search/articles?q=dengue` | API pública `/api/search/articles/{query}`; termo extraído de `q`, `query` ou inserido **manualmente** na engrenagem. Filtros complexos da interface não são traduzidos; inserir termo manual cria uma **nova busca API sem esses filtros**. |
| **SciELO (experimental)** | `https://search.scielo.org/?q=dengue&lang=pt` | HTML paginado; preserva os parâmetros da URL. Dependente da estrutura da página e sujeito a bloqueios. Se o formato HTML mudar, informa erro. |
| **bioRxiv** | `https://www.biorxiv.org/` | API oficial **por intervalo de datas**, com filtro textual local opcional, não a mesma busca da interface. |
| **medRxiv** | `https://www.medrxiv.org/` | API oficial **por intervalo de datas**, com filtro textual local opcional, não a mesma busca da interface. |

**bioRxiv e medRxiv:** abra a engrenagem, selecione as datas (padrão: últimos 7 dias) e, se quiser, informe um trecho literal que deva estar no título ou no resumo. O coletor varre no máximo 2.000 metadados do intervalo por execução. Com filtro textual, a seleção pode ser **parcial e não exaustiva**; o arquivo não deve ser apresentado como equivalente à consulta do site. Para busca reprodutível por assunto nessas plataformas, considere também Europe PMC e outros indexadores, registrando as diferenças de cobertura.

**SciELO:** usa seletores HTML (`.item`, `.title`, `.authors`, `.DOIResults`) e as páginas ordenadas pelo site; não é uma API científica oficialmente versionada. Conteúdos podem ser bloqueados ou seus seletores mudarem. Não interpretamos uma página HTML vazia como conclusão científica quando há indícios de resultado.

## Biblioteca local, DOI, histórico e Zotero

- **Biblioteca unificada:** por padrão, após baixar resultados, a opção **Adicionar à biblioteca local** está ativa. Ao clicar na engrenagem, o painel exibe a contagem de artigos únicos, os oito registros mais recentes do histórico e exportações da biblioteca inteira.
- **Deduplicação:** DOI normalizado é a chave principal; sem DOI, utiliza `fonte:identificador`. Não une registros apenas por título para reduzir falsos positivos. O campo `sources` preserva as fontes que compartilharam um DOI. Preprint e artigo publicado com DOIs diferentes **continuam separados**.
- **Metadados combinados:** mantém campos mais completos quando os registros compartilham o mesmo DOI, mas isso **não é reconciliação bibliográfica validada**.
- **Histórico:** armazena localmente URL, data, fonte, recebidos, novos, combinados e status parcial. Até **80 coletas**; biblioteca limitada a **12.000 registros únicos**. Se o limite for atingido, os itens excedentes são informados e não salvos.
- **Privacidade:** `chrome.storage.local` + permissão `unlimitedStorage`; dados ficam no perfil local do navegador. Não são sincronizados com conta DELTA IA nem enviados a servidores próprios. Para excluir, use **Apagar biblioteca e histórico**, com confirmação. **A exclusão não apaga os arquivos exportados.**
- **Zotero:** clique em **Exportar RIS / Zotero** na área da biblioteca; no Zotero, escolha **Arquivo → Importar → Um arquivo** e selecione `.ris`. Você também pode exportar `.bib`. **Não existe escrita direta na biblioteca Zotero nem instalação de plugin Zotero** nesta versão.
- **Rastreabilidade:** CSV/JSON incluem a origem e carimbo UTC; BibTeX exportado por busca inclui comentários com a URL e a data da coleta. JSON da biblioteca contém as entradas de histórico.

## Cuidados com revisão sistemática

- Páginas e APIs podem diferir em critérios, ranking, atualização e filtros. Sempre guarde **estratégia de busca, data, fonte, limite e número de resultados** e confira contra a interface.
- Os limites configuráveis são 50, 200, 500, 1.000 ou 2.000; não significam extração exaustiva. Semantic Scholar tem teto de 1.000; bioRxiv e medRxiv têm teto de 2.000 **registros examinados**.
- Em caso de erro depois de coletar parte dos resultados, pode ser gerado um arquivo **parcial**, com aviso no painel. Dados podem ser armazenados e marcados parciais no histórico.
- PDFs em lote **somente arXiv**, até 20 solicitações, sem contornar paywalls, CAPTCHA, login ou direitos de acesso. Nas outras bases são apenas links de PDF quando a API oferece.
- Respeite os termos das plataformas e taxas de requisição. Esta ferramenta não substitui triagem, análise de elegibilidade ou auditoria bibliográfica manual.

## Testes locais (não são testes ao vivo)

```bash
node tests/test-core.cjs
node tests/test-background.cjs
```

Foram executados: checagens de sintaxe JS, testes das seis bases anteriores, parsers e construtores de URL novos, deduplicação DOI, RIS, armazenamento/histórico simulado, parser SciELO com HTML sintético no Chromium e interface/CSV com resposta DOAJ simulada no Chromium. **Não foi possível consultar APIs remotas nem executar a extensão instalada no Opera GX neste ambiente.** Confirme as chamadas reais no seu navegador.

## Fontes e créditos

Inspirado no [arxivcollector](https://github.com/koenraijer/arxivcollector) de Koen Raijer (GPL-3.0). Código JavaScript independente; licença GPL-3.0-or-later, arquivo `LICENSE` incluído. Outros recursos: [DOAJ API](https://doaj.org/api/v4/docs), [bioRxiv API](https://api.biorxiv.org/), [SciELO Search](https://search.scielo.org/), [Zotero importação](https://www.zotero.org/support/kb/importing_standardized_formats).
